package br.edu.umfg.aula09102023.entidades;

public class Help {
    private String mensagem;

    public Help(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    // Getter e setter
}