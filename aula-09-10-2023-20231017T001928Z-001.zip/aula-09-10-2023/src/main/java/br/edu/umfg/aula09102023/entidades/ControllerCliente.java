package br.edu.umfg.aula09102023.entidades;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/clientes")
public class ControllerCliente {
    private final List<Cliente> clientes = new ArrayList<>();
    private long proximoId = 1;

    @PostMapping
    public Cliente criarCliente(@RequestBody Cliente cliente) {
        cliente.setId(proximoId++);
        clientes.add(cliente);
        return cliente;
    }

    @GetMapping
    public List<Cliente> listarClientes() {
        return clientes;
    }

    @GetMapping("/{id}")
    public Cliente buscarClientePorId(@PathVariable long id) {
        Optional<Cliente> clienteEncontrado = clientes.stream()
                .filter(cliente -> cliente.getId() == id)
                .findFirst();

        return clienteEncontrado.orElse(null);
    }
}
