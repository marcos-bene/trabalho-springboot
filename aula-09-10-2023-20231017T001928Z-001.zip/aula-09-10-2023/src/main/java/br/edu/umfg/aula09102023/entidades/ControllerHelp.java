package br.edu.umfg.aula09102023.entidades;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/help")
public class ControllerHelp {

    @GetMapping
    public Help obterMensagemDeAjuda() {
        String mensagemDeAjuda = "Bem-vindo à API de Clientes!\n"
                + "Para criar um novo cliente, faça uma requisição POST para /clientes.\n"
                + "Para listar todos os clientes, faça uma requisição GET para /clientes.\n"
                + "Para buscar um cliente por ID, faça uma requisição GET para /clientes/{id}.";

        return new Help(mensagemDeAjuda);
    }
}