package br.edu.umfg.aula09102023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula09102023Application {
	public static void main(String[] args) {
		SpringApplication.run(Aula09102023Application.class, args);
	}
}